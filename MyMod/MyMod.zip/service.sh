#!/system/bin/sh
MODDIR=${0%/*}
DEVICE=/dev/input/event3
X1=330
X2=720
X3=1110
Y1=1650
Y2=2090
Y3=2530
setprop audio.camerasound.force false
#boot detection
until [ $(getprop init.svc.bootanim) = "stopped" ]
do
sleep 2
done
sleep 2

function touchdown()
{
if [ $2 = 0 ]
then

sendevent $DEVICE 3 58 0
sendevent $DEVICE 3 57 -1
sendevent $DEVICE 3 52 0
sendevent $DEVICE 1 330 $1
sendevent $DEVICE 0 0 0
else
sendevent $DEVICE 1 330 $1
sendevent $DEVICE 3 57 99
sendevent $DEVICE 3 58 $2
sendevent $DEVICE 3 48 77
sendevent $DEVICE 3 49 77
sendevent $DEVICE 3 52 -10
fi
}

function swipeto()
{
sleep 0.5
sendevent $DEVICE 3 53 $1
sendevent $DEVICE 3 54 $2
sendevent $DEVICE 0 0 0
}

function swipeup()
{
touchdown 1 18
swipeto $X2 $Y3
swipeto $X2 $Y1
swipeto $X2 500
touchdown 0 0
}

swipeup
sleep 2
touchdown 1 18
swipeto $X1 $Y1
swipeto $X1 $Y2
swipeto $X1 $Y3
swipeto $X2 $Y3
swipeto $X3 $Y3
swipeto $X2 $Y2
swipeto $X3 $Y2
swipeto $X2 $Y1
swipeto $X3 $Y1
touchdown 0 0

